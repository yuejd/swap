function getCookie(name) {
    var r = document.cookie.match("\\b" + name + "=([^;]*)\\b");
    return r ? r[1] : undefined;
}

nodefind_req = function(){
    $("#nodefind_result_msg").html("<div class='alert alert-info' role='alert'>" +  "finding, please wait......" + "</div>");
    $("#nodefind_result").html("");
    $("#nodefind_bt").attr("disabled", true);
    $.post("/nodefind", {
                        _xsrf:getCookie("_xsrf"),
                        ipaddr:$("#ip").val(),
                        username:$("#username").val(),
                        passwd:$("#passwd").val(),
                        devtype:$("#devtype").val()
                        },
                      function(data,textStatus){
      $("#nodefind_result_msg").html("");
      $("#nodefind_result").html(data);
      $("#nodefind_bt").attr("disabled", false);
    });
  };

search_req = function(){
    $.get("/search", {"search_ip":$("#search_ip").val()},
                      function(data,textStatus){
      $("#search_result").html(data);
    });
  };

zoning_req = function(){
  $("#search_bt").toggle();
  $("#zoning_bt").toggle();
  $("#del_zoning_bt").toggle();
  $("#zone_result").html("<div class='alert alert-info' role='alert'>" +
                         "zoning, please wait......" +
                         "</div>");
  if($("#zone_name").val() && $("#wwns").val()){
    $.get("/zoning", {"zone_name":$("#zone_name").val(),
                      "wwns":$("#wwns").val(),
                      "dev":$("#slc_br_ci").val(),
                      "env":$("#slc_zone_env").val()}, 
                     function(data, textStatus){
      $("#search_bt").toggle();
      $("#zoning_bt").toggle();
      $("#del_zoning_bt").toggle();
      $("#zone_result").html("<div class='alert alert-success' role='alert'>" + 
                             "zone create success" +
                             "</div>");
  });
  }else{
      $("#search_bt").toggle();
      $("#zoning_bt").toggle();
      $("#del_zoning_bt").toggle();
      $("#zone_result").html("<div class='alert alert-danger' role='alert'>" +
                             "zone name and wwns can't be empty!" +
                             "</div>");
  };
};

del_zone_req = function(){
  $("#search_bt").toggle();
  $("#zoning_bt").toggle();
  $("#del_zoning_bt").toggle();
  $("#zone_result").html("<div class='alert alert-info' role='alert'>" +
                         "deleting zone, please wait......" +
                         "</div>");
  if($("#del_zone_name").val()){
    $.get("/delzone", {"zone_name":$("#del_zone_name").val(),
                       "dev":$("#del_slc_br_ci").val(),
                       "env":$("#del_slc_zone_env").val()}, 
                     function(data, textStatus){
      $("#search_bt").toggle();
      $("#zoning_bt").toggle();
      $("#del_zoning_bt").toggle();
      $("#zone_result").html("<div class='alert alert-success' role='alert'>" + 
                             "zone delete success" +
                             "</div>");
  });
  }else{
      $("#search_bt").toggle();
      $("#zoning_bt").toggle();
      $("#del_zoning_bt").toggle();
      $("#zone_result").html("<div class='alert alert-danger' role='alert'>" +
                             "zone name can't be empty!" +
                             "</div>");
  };
};

$(document).ready(function(){  

  $("#nodefind_bt").click(nodefind_req);
//  $("#search_bt").click(search_req);
//  $("#zoning_bt").click(zoning_req);
//  $("#del_zoning_bt").click(del_zone_req);


});
